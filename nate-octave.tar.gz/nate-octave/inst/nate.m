function nate
%NATE   Library identification
%
%   NATE prints the name of the library.
%
%   Copyright 2019 Brian Sutton

fprintf('Numerical Analysis: Theory and Experiments\n');

